<script setup lang="ts">
import { SearchIcon} from 'lucide-vue-next'
</script>

<template>
    <div class="mb-6">
      <div class="relative">
        <SearchIcon class="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
        <input type="text" placeholder="Busca un instrumento"
          class="w-full bg-[#2a2a2a] text-white placeholder-gray-400 pl-10 pr-4 py-2 rounded-md border border-gray-700 focus:outline-none focus:border-blue-500" />
      </div>
    </div>
</template>