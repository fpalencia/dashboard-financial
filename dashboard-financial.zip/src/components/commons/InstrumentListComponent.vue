<script setup lang="ts">
import { ref, computed } from 'vue'
import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { useChartStore } from '@/store/useChartStore'
import { ChevronUpIcon, ChevronDownIcon } from 'lucide-vue-next'
import type { Constituent } from '@/types/constituyentes'
import InstrumentItemComponent from '@/components/commons/InstrumentItemComponent.vue'

const useChart = useChartStore()
const sortColumn = ref('shortName')
const sortDirection = ref('asc')


const sortedConstituents = computed(() => {
  const constituents: Constituent[] = [...useChart.$state.constituents]
  if (sortColumn.value) {
    constituents.sort((a, b) => {
      let aValue = a[sortColumn.value]
      let bValue = b[sortColumn.value]
      
      if (['lastPrice', 'accumulatedVolumeMoney', 'pctDay', 'pct30D', 'pct1Y', 'pctCY'].includes(sortColumn.value)) {
        aValue = Number(aValue)
        bValue = Number(bValue)
      }
      
      if (aValue < bValue) return sortDirection.value === 'asc' ? -1 : 1
      if (aValue > bValue) return sortDirection.value === 'asc' ? 1 : -1
      return 0
    })
  }
  return constituents
})

const handleSort = (column:string) => {
  if (sortColumn.value === column) {
    sortDirection.value = sortDirection.value === 'asc' ? 'desc' : 'asc'
  } else {
    sortColumn.value = column
    sortDirection.value = 'asc'
  }
}

const getSortIcon = (column:string) => {
  if (sortColumn.value !== column) return null
  return sortDirection.value === 'asc' ? ChevronUpIcon : ChevronDownIcon
}

const handleClick = (value: string) => {
  useChart.getHistory(value)
}
</script>

<template>
  <div class="w-full rounded-lg">
    <div class="flex">
      <div class="w-1/2 mr-5">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead @click="handleSort('shortName')" class="text-white cursor-pointer">
                Nombre
                <component :is="getSortIcon('shortName')" v-if="sortColumn === 'shortName'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('lastPrice')" class="text-right text-white cursor-pointer">
                Último
                <component :is="getSortIcon('lastPrice')" v-if="sortColumn === 'lastPrice'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('accumulatedVolumeMoney')" class="text-right text-white cursor-pointer">
                Monto (MM)
                <component :is="getSortIcon('accumulatedVolumeMoney')" v-if="sortColumn === 'accumulatedVolumeMoney'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('pctDay')" class="text-right text-white cursor-pointer">
                Var día
                <component :is="getSortIcon('pctDay')" v-if="sortColumn === 'pctDay'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('pct30D')" class="text-right text-white cursor-pointer">
                Var 30d**
                <component :is="getSortIcon('pct30D')" v-if="sortColumn === 'pct30D'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('pct1Y')" class="text-right text-white cursor-pointer">
                Año Actual
                <component :is="getSortIcon('pct1Y')" v-if="sortColumn === 'pct1Y'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('pctCY')" class="text-right text-white cursor-pointer">
                12 Meses
                <component :is="getSortIcon('pctCY')" v-if="sortColumn === 'pctCY'" class="inline ml-1" />
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow v-for="(data, index) in sortedConstituents.slice(0, 16)" :key="index" class="hover:bg-gray-800 cursor-pointer" @click="handleClick(data.shortName)">
              <InstrumentItemComponent :data="data" />
            </TableRow>
          </TableBody>
        </Table>
      </div>
      <div class="w-1/2 mr-4">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead @click="handleSort('shortName')" class="text-white cursor-pointer">
                Nombre
                <component :is="getSortIcon('shortName')" v-if="sortColumn === 'shortName'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('lastPrice')" class="text-right text-white cursor-pointer">
                Último
                <component :is="getSortIcon('lastPrice')" v-if="sortColumn === 'lastPrice'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('accumulatedVolumeMoney')" class="text-right text-white cursor-pointer">
                Monto (MM)
                <component :is="getSortIcon('accumulatedVolumeMoney')" v-if="sortColumn === 'accumulatedVolumeMoney'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('pctDay')" class="text-right text-white cursor-pointer">
                Var día
                <component :is="getSortIcon('pctDay')" v-if="sortColumn === 'pctDay'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('pct30D')" class="text-right text-white cursor-pointer">
                Var 30d**
                <component :is="getSortIcon('pct30D')" v-if="sortColumn === 'pct30D'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('pct1Y')" class="text-right text-white cursor-pointer">
                Año Actual
                <component :is="getSortIcon('pct1Y')" v-if="sortColumn === 'pct1Y'" class="inline ml-1" />
              </TableHead>
              <TableHead @click="handleSort('pctCY')" class="text-right text-white cursor-pointer">
                12 Meses
                <component :is="getSortIcon('pctCY')" v-if="sortColumn === 'pctCY'" class="inline ml-1" />
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow v-for="(data, index) in sortedConstituents.slice(16, 32)" :key="index" class="hover:bg-gray-800 cursor-pointer" @click="handleClick(data.shortName)">
              <InstrumentItemComponent :data="data" />
            </TableRow>
          </TableBody>
        </Table>
      </div>
    </div>
  </div>
</template>

<style scoped>
.table-container {
  overflow-x: auto;
}
</style>