<script setup lang="ts">

</script>

<template>
  <div class="flex justify-between items-center">
    <div>
      <h1 class="text-2xl font-bold text-white mb-3">ENEL CHILE</h1>
      <span class="text-gray-400 text-sm">Indice</span>
    </div>
  </div>
  <div class="mb-6 border-y-[1px] py-2 mr-5">
    <div class="flex gap-4 text-sm text-gray-400">
      <span>Valor Actual 6.474,37</span>
      <span>Var.% -0,78%</span>
      <span>Var. Puntos Actual -51,01</span>
    </div>
  </div>
</template>