<script setup lang="ts">
import { ref } from 'vue'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'

const portfolio = ref([
  { name: 'FALABELLA', price: '3.435,00', change: 3.78 },
  { name: 'ENEL CHILE', price: '53.89', change: 2.67 },
  { name: 'BSANTANDER', price: '47.37', change: 2.09 },
  { name: 'SQM-B', price: '38.988,00', change: 0.24 },
])

const currencies = ref([
  { name: 'DOLAR SPOT', value: '999.71', change: 0.43 },
  { name: 'UF', value: '38.858.100', change: 0.67 },
  { name: 'REAL BRASILEÑO', value: '5.7056', change: -0.38 },
])

const markets = ref([
  { name: 'IPSA, CHILE', value: '6.527,82', change: 0.74 },
  { name: 'IBOVESPA, BRASIL', value: '127.791,68', change: 0.85 },
  { name: 'MERVAL, ARG', value: '2.865.915,29', change: -0.99 },
])

const topGainers = ref([
  { name: 'CAROZZI', price: '2.500,00', change: '+4.70' },
  { name: 'FALABELLA', price: '3.435,00', change: '+3.78' },
  { name: 'VENTANAS', price: '140,00', change: '+2.94' },
  { name: 'ENELCHILE', price: '53,89', change: '+2.67' },
  { name: 'NORTEGRAN', price: '6.25', change: '+2.46' },
])

const topLosers = ref([
  { name: 'ENJOY', price: '0.27', change: '-5.64' },
  { name: 'CENCOSUD', price: '1.488,00', change: '-3.88' },
  { name: 'CAP', price: '5.390,00', change: '-2.00' },
  { name: 'MINERA', price: '13.500,00', change: '-1.92' },
  { name: 'SALFACORP', price: '567,00', change: '-1.42' },
])

const mostTraded = ref([
  { name: 'FALABELLA', price: '3.435,00', change: '+3.78' },
  { name: 'SQM-B', price: '36.988,00', change: '+0.24' },
  { name: 'LTM', price: '13.48', change: '-1.25' },
  { name: 'CMPC', price: '1.522,00', change: '-0.33' },
  { name: 'ENELCHILE', price: '53,89', change: '+2.67' },
])
</script>

<template>
  <Tabs default-value="resumen" class="w-full">
    <TabsList class="border-b border-gray-800 bg-[#1a1a1a] text-white w-full flex justify-start pb-3">
      <TabsTrigger value="resumen" class="text-sm">Resumen</TabsTrigger>
      <TabsTrigger value="detalles" class="text-sm">Detalles</TabsTrigger>
    </TabsList>
    <TabsContent value="resumen">
      <div class="space-y-6">
        <!-- Mayores alzas -->
        <div>
          <div class="flex justify-between items-center mb-2">
            <h3 class="text-gray-400">Mayores alzas</h3>
            <span class="text-gray-400">%</span>
          </div>
          <table class="w-full text-xs">
            <tbody>
              <tr v-for="stock in topGainers" :key="stock.name" class="border-b border-gray-800">
                <td class="py-2">{{ stock.name }}</td>
                <td class="text-right">{{ stock.price }}</td>
                <td class="text-right text-green-400">{{ stock.change }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Mayores bajas -->
        <div>
          <div class="flex justify-between items-center mb-2">
            <h3 class="text-gray-400">Mayores bajas</h3>
            <span class="text-gray-400">%</span>
          </div>
          <table class="w-full text-xs">
            <tbody>
              <tr v-for="stock in topLosers" :key="stock.name" class="border-b border-gray-800">
                <td class="py-2">{{ stock.name }}</td>
                <td class="text-right">{{ stock.price }}</td>
                <td class="text-right text-red-400">{{ stock.change }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Más transadas -->
        <div>
          <div class="flex justify-between items-center mb-2">
            <h3 class="text-gray-400">Más transadas</h3>
            <span class="text-gray-400">%</span>
          </div>
          <table class="w-full text-xs">
            <tbody>
              <tr v-for="stock in mostTraded" :key="stock.name" class="border-b border-gray-800">
                <td class="py-2">{{ stock.name }}</td>
                <td class="text-right">{{ stock.price }}</td>
                <td class="text-right" :class="stock.change.startsWith('+') ? 'text-green-400' : 'text-red-400'">
                  {{ stock.change }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </TabsContent>
    <TabsContent value="detalles">
      <!-- Add details content here -->
    </TabsContent>
  </Tabs>
</template>