export const getDateFromTimestamp = (timestamp: number) => {
  return new Date(timestamp * 1000)
}

export const formattedValue = (value: number) => {
  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    minimumFractionDigits: 0,
  }).format(value);
}

export const formattedValueWithDecimals = (value: number) => {
  return new Intl.NumberFormat('es-CL', {
    style: 'decimal',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

export const formatNumber = (value: number): string => {
  return new Intl.NumberFormat('es-CL', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

export const formatPercentage = (value: number): string => {
  return `${value > 0 ? '+' : ''}${value.toFixed(2)}%`
}

export const getValueColor = (value: number): string => {
  return value < 0 ? 'text-red-500' : value > 0 ? 'text-green-500' : 'text-white'
}