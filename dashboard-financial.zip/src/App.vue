<script setup lang="ts">
import SearchBarComponent from './components/commons/SearchBarComponent.vue'
import HeaderComponent from './components/commons/HeaderComponent.vue'
import ChartComponent from './components/commons/ChartComponent.vue'
import InstrumentListComponent from './components/commons/InstrumentListComponent.vue'
import SummaryComponent from './components/commons/SummaryComponent.vue'

import { useChartStore } from './store/useChartStore'
import TabComponent from './components/commons/TabComponent.vue'

const useChart = useChartStore()

useChart.getConstituents()

useChart.getHistory('IPSA')

</script>

<template>
  <div class="min-h-screen bg-[#1a1a1a] text-white p-4">
    <!-- SearchBarComponent -->
    <SearchBarComponent />

    <div class="flex flex-col lg:flex-row">
      <div class="w-full lg:w-3/4">
        <!-- HeaderComponent -->
        <HeaderComponent />
        <!-- ChartComponent -->
        <ChartComponent />
        <!-- InstrumentListComponent -->
        <TabComponent>
          <template #ipsa>
            <InstrumentListComponent />
          </template>
          <template #igpa>
            <!-- Add details content here -->
          </template>
          <template #nasdaq>
            <!-- Add details content here -->
          </template>
          <template #dowjones>
            <!-- Add details content here -->
          </template>
        </TabComponent>
      </div>

      <!-- SummaryComponent  -->
      <div class="w-full lg:w-1/4">
        <SummaryComponent />
      </div>
    </div>
  </div>
</template>