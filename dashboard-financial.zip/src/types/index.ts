export type InstrumentItem = {
  name: string;
  last: number;
  volume: number;
  dayChange: number;
  month30Change: number;
  yearChange: number;
  months12Change: number;
}