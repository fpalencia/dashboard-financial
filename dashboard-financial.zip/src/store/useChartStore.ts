import { defineStore } from "pinia";

export const useChartStore = defineStore("useChartStore", {
  state: () => ({
    constituents: [],
    history: {
      info: [],
      chart: []
    }
  }),
  actions: {
   async getConstituents() {
      try {
        const response = await fetch(`/data/constituyentes/constituensList.json`);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const jsonData = await response.json();
        this.constituents = jsonData.data.constituents;
      } catch (error) {
        console.error('There has been a problem with your fetch operation:', error);
        return null;
      }
    },
    async getHistory(value:string) {
      try {
        const response = await fetch(`/data/history/history-${value}.json`);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const jsonData = await response.json();
        this.history = jsonData.data;
      } catch (error) {
        console.error('There has been a problem with your fetch operation:', error);
        return null;
      }
    }
  }
});